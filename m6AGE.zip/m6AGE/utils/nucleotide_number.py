nuc2num_dict = {'A': 0, 'C': 1, 'G': 2, 'U': 3}
num2nuc_dict = {0: 'A', 1: 'C', 2: 'G', 3: 'U'}